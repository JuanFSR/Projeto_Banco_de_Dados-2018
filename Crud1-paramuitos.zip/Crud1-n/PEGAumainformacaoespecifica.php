
<?php
	session_start();
	if(!isset($_SESSION["email"]) || !isset($_SESSION["senha"])){
		header("Location: login.php");
		exit;
	}
?>

<?php include_once("conectaProd.php");
$result_produto = "SELECT * FROM produtos WHERE id_prod='1'";
$resultado_produto = mysqli_query($conn, $result_produto);
	if($resultado_produto == FALSE){
		die(mysqli_error());
	}

$row_produto = mysqli_fetch_assoc($resultado_produto);
?>


<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="widh= device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="painel.css">
</head>

<body>

	<nav class="menu">
		<ul>
		<li><a href="#">Home</a></li>
		<li><a href="#">Categoria</a>
			<ul>
				<li><a href="#">Roupas</a></li>
				<li><a href="#">Tênis</a></li>
				<li><a href="#">Eletrônicos</a></li>
				<li><a href="#">Computadores</a></li>
				<li><a href="#">Relógios</a></li>
			</ul>
		</li>
		<li><a href="#">Produto</a>
			<ul>
				<li><a href="#">Adicionar Prod.</a></li>
			</ul>
		</li>
		<li><a href="#">Carrinho</a>
			<ul>
			<li><a href="#">Ver carrinho</a></li>
			</ul>
		</li>
		<li><a href="logout.php">Sair</a></li>
		<li><a href="#"> Nome</a></li>

		<ul>
	</nav>
	<br>
<div id="barr" class="barras">
		
		<div id="divBusca">
  		<form name="buscar" method="post" action="results.php">
  			<input type="text" class="txtBusca" id="txtBusca" placeholder="Buscar..."/>
  			<input type="submit" class="btnBusca" name="btnBusca" value="Buscar">
		</form>
		</div>

		<div id="produtos">

			<!--font color="#000"><?php echo $row_produto['nome']; ?></font-->
		</div>


</body>


</html>