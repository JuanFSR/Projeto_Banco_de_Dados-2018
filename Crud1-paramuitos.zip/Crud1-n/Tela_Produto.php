<?php 

$host = "localhost";
$user = "root";
$pass = "";
$banco = "criar_produto";
$conexao = mysqli_connect($host, $user, $pass, $banco) or die(mysqli_error());
    if(!$conexao){
        print "Falha na conexão com o Banco de Dados";
    }

$selectDB = mysqli_select_db($conexao, $banco) or die(mysqli_error());

            if(isset($_POST['Cadastrar'])){
$nome=$_POST['nome'];
$descricao =$_POST['descricao'];
$preco=$_POST['preco'];
$vendedor=$_POST['vendedor'];
$id_prod=$_POST['id_prod'];
$categoria=$_POST['categoria'];
$nome_imagem=$_POST['confirmacao_senha'];
$sql = mysqli_query($conexao,"INSERT INTO produtos (nome, descricao,preco,vendedor,id_prod,categoria, confirmacao_senha)
    VALUES('$nome', '$descricao', '$preco', '$vendedor', '$id_prod', '$categoria', '$confirmacao_senha')");

echo"<center><h1>Cadastro efetuado com sucesso!</h1></center>";
mysqli_close($conexao);
}
?>

<html>
<head>
	<title>Tela de cadastro do produto</title>
	<link rel="stylesheet" type="text/css" href="Tela_Produto.css">
</head>
<body>
	
	 <nav class="menu">
        <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Categoria</a>
            <ul>
               <li><a href="#">Roupas</a></li>
                <li><a href="#">Eletrônicos</a></li>
                <li><a href="#">Computadores</a></li>
                <li><a href="#">Esportes</a></li>
            </ul>
        </li>
        <li><a href="#">Produto</a>
            <ul>
                <li><a href="#">Adicionar Prod.</a></li>
            </ul>
        </li>
        <li><a href="#">Carrinho</a>
            <ul>
            <li><a href="#">Ver carrinho</a></li>
            </ul>
        </li>
        <li><a href="logout.php">Sair</a></li>
        <li><a href="#"> Nome</a></li>

        <ul>
    </nav>
    <br>
<div id="barr" class="barras">
        
        <div id="divBusca">
        <form name="buscar" method="post" action="results.php">
            <input type="text" class="txtBusca" id="txtBusca" placeholder="Buscar..."/>
            <input type="submit" class="btnBusca" name="btnBusca" value="Buscar">
        </form>
        </div>


	<div id="cadastra">
		<form action="proc_upload.php" method="post">
			<label for="nome_p">Nome do produto</label><input id="nome_p"type="text" class="txt bradius"name="nome_p" value=""/>
				<label for="descricao">Descrição do produto</label><input id="descricao"type="text" class="txt bradius"name="descricao" value=""/>
				<label for="preco">Preço</label><input id="preco"type="text" class="txt bradius"name="preco" value=""/>
				<label for="categoria">Categoria</label><input id="categoria"type="text" class="txt bradius"name="categoria" value=""/>
                <p>Escolha a imagem do produto<input type="file" name="Arquivo" class="sb bradius"  /></p>
				<input type="submit" class="sb bradius" value="Cadastrar" name="Cadastrar"/>
		</form>
	</div>



</body>
</html>