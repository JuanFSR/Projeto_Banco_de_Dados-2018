<html>
	<head>
		<title>Pag- Login</title>
		<link rel="stylesheet" type="text/css" href="LoginN.css"/>
		<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet"/>
	</head>
	
	<body>
		<div id="cadastrar"><a href="#" title="Cadastre-se">Cadastre-se &raquo;</a></div>

		<div id="login" class="form bradius">
			<!--div id="logo"><a href="#"><img src="logo.png"/></a></div-->
			<div class="message"></div>
			<div class="logo"></div>
			<div class="acomodar">
				<form action="autenticacao.php" method="post">
				<label for="email">E-mail</label><input id="email"type="text" class="txt bradius"name="email" value=""/>
				<label for="senha">Senha</label><input id="senha"type="password" class="txt bradius"name="senha" value=""/>
				<input type="submit" class="sb bradius" value="Entrar"/>
				<div id="esqueci_senha"><a href="#">Esqueci minha senha</a></div>
			</form>
			</div>

		</div>





	</body>








</html>