
<?php
    session_start();
    if(!isset($_SESSION["email"]) || !isset($_SESSION["senha"])){
        header("Location: login.php");
        exit;
    }
?>

<?php include_once("conectaProd.php");
$result_produto = "SELECT * FROM produtos";
$resultado_produto = mysqli_query($conn, $result_produto);

?>


<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="widh= device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="painel.css">
       <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>

<body>
   

    <nav class="menu">
        <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Categoria</a>
            <ul>
                <li><a href="#">Roupas</a></li>
                <li><a href="#">Eletrônicos</a></li>
                <li><a href="#">Computadores</a></li>
                <li><a href="#">Esportes</a></li>
                <li><a href="#">Casa</a></li>
            </ul>
        </li>
        <li><a href="#">Produto</a>
            <ul>
                <li><a href="#">Adicionar Prod.</a></li>
            </ul>
        </li>
        <li><a href="#">Carrinho</a>
            <ul>
            <li><a href="#">Ver carrinho</a></li>
            </ul>
        </li>
        <li><a href="logout.php">Sair</a></li>
        <li><a href="#"> Nome</a></li>

        <ul>
    </nav>
    <br>
<div id="barr" class="barras">
        
        <div id="divBusca">
        <form name="buscar" method="post" action="results.php">
            <input type="text" class="txtBusca" id="txtBusca" placeholder="Buscar..."/>
            <input type="submit" class="btnBusca" name="btnBusca" value="Buscar">
        </form>
        </div>
        <br><br>

        <!-- Agora está funcionando -->
           <div id="row" class="row">
        <?php while($rows_produto = mysqli_fetch_assoc($resultado_produto)){ ?>

  <div id="colun" class="col-xs-6 col-md-3">
    <div id="thumbnail" class="thumbnail">
      <img src="tenis.jpg" alt="">
      <div class="caption text-center">
        <h3><?php echo $rows_produto['nome']; ?></h3>
        <p><?php echo $rows_produto['preco']; ?></p>
        <p><a href="#" class="btn btn-primary" role="button">Comprar</a></p>
      </div>
    </div>
  </div>
    <?php } ?>
</div>
        </div>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script scr="js/bootstrap.min.js"></script>
</body>


</html>