
<html>
<head>
    <title>Tela de cadastro do produto</title>
    <link rel="stylesheet" type="text/css" href="tela_prod.css">
</head>
<body>
    
     <nav class="menu">
        <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Categoria</a>
            <ul>
               <li><a href="#">Roupas</a></li>
                <li><a href="#">Eletrônicos</a></li>
                <li><a href="#">Computadores</a></li>
                <li><a href="#">Esportes</a></li>
                <li><a href="#">Casa</a></li>
            </ul>
        </li>
        <li><a href="#">Produto</a>
            <ul>
                <li><a href="#">Adicionar Prod.</a></li>
            </ul>
        </li>
        <li><a href="#">Carrinho</a>
            <ul>
            <li><a href="#">Ver carrinho</a></li>
            </ul>
        </li>
        <li><a href="logout.php">Sair</a></li>
        <li><a href="#"> Nome</a></li>

        <ul>
    </nav>
    <br>
<div id="barr" class="barras">
        
        <div id="divBusca">
        <form name="buscar" method="post" action="results.php" encrype="multipart/form-data" >
            <input type="text" class="txtBusca" id="txtBusca" placeholder="Buscar..."/>
            <input type="submit" class="btnBusca" name="btnBusca" value="Buscar">
        </form>
        </div>


    <div id="cadastra">
        <form action="proc_upload.php" method="POST" enctype="multipart/form-data">
            <label for="nome_p">Nome do produto</label><input id="nome_p"type="text" class="txt bradius"name="nome_p" value=""/>
                <label for="descricao">Descrição do produto</label><input id="descricao"type="text" class="txt bradius"name="descricao" value=""/>
                <label for="preco">Preço</label><input id="preco"type="text" class="txt bradius"name="preco" value=""/>
                 <label for="vendedor">Vendedor</label><input id="descricao"type="text" class="txt bradius"name="vendedor" value=""/>
                <label for="categoria">Categoria</label><input id="categoria"type="text" class="txt bradius"name="categoria" value=""/>
                 <label for="quantidade">Quantidade</label><input id="quantidade"type="text" class="txt bradius"name="quantidade" value=""/>
        
                <label>Imagem</label><br>
                <input for="arquivo" type="file" name="arquivo" >
                <input type="submit" class="sb bradius" value="Cadastrar"/>
        </form>
    </div>

</body>
</html>