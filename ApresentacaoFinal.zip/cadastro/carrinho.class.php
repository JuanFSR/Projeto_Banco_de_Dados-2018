<?php
	final class Carrinho{
		public function_construct(){
			if(!isset($_SESSION['carrinho'])){
				$_SESSION['carrinho'] = array();
			}
		}

		public function adicionarProduto($id,$quantidade=1){
			if(is_null($id)){
				$indice = sprintf("%s", (int)$id,0);
			}

			if(!isset($_SESSION['carrinho'][$indice])){
				$_SESSION['carrinho'][$indice] = (int)$quantidade;
			}


		}

	}

?>