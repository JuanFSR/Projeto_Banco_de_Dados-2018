<?php
	include_once("conexaoPro.php");
	$nome = $_POST['nome_p'];
	$descricao = $_POST['descricao'];
	$preco= $_POST['preco'];
	$vendedor = $_POST['vendedor'];
	$categoria= $_POST['categoria'];
	$nome_imagem = $_FILES['arquivo']['name'];
	echo "Nome da Imagem: $nome_imagem";
	$pasta_dir = "upload./";
	//Salvar no BD
		$result_produto= "INSERT INTO produtos(nome, descricao, preco, vendedor, categoria, nome_imagem) VALUES('$nome', '$descricao', '$preco', '$vendedor', '$categoria', '$nome_imagem') ";
		$resultado_produto= mysqli_query($conn, $result_produto);

		//onde o arquivo vai ser salvo
		//Criar a pasta de imagens do produto
		/*
		if(!file_exists($_UP['pasta'])){
		mkdir($_UP['pasta'],  0777);
	}
*/	
	move_uploaded_file($FILES['arquivo']['name'], $pasta_dir.$nome_arquivo);

	if(move_uploaded_file($nome_imagem["tmp_name"], $arquivo_nome)){
		echo "Imagem salva com sucesso";
	}

?>