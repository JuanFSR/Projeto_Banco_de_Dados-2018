<?php 

$host = "localhost";
$user = "root";
$pass = "";
$banco = "cadastro";
$conexao = mysqli_connect($host, $user, $pass, $banco) or die(mysqli_error());
	if(!$conexao){
		print "Falha na conexão com o Banco de Dados";
	}

$selectDB = mysqli_select_db($conexao, $banco) or die(mysqli_error());

			if(isset($_POST['Cadastrar'])){
$nome=$_POST['nome'];
$sobrenome =$_POST['sobrenome'];
$pais=$_POST['pais'];
$regiao=$_POST['regiao'];
$email=$_POST['email'];
$senha=$_POST['senha'];
$confirmacao_senha=$_POST['confirmacao_senha'];
$sql = mysqli_query($conexao,"INSERT INTO usuarios (nome, sobrenome, pais, regiao, email, senha, confirmacao_senha)
	VALUES('$nome', '$sobrenome', '$pais', '$regiao', '$email', '$senha', '$confirmacao_senha')");

echo"<center><h1>Cadastro efetuado com sucesso!</h1></center>";
mysqli_close($conexao);
}

?>


<html>
<head>
	<title>Cadastro</title>
	<link rel="stylesheet" type="text/css" href="cadastroNovo.css">
	<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet"/>
</head>

<body>
	<div id="log">
 <a href="login.php" class="bradius">Login</a>
 	</div>
	<div id="cadastrar">
		<form name="cadastro" action="conexao.php" method="post">
			<label>Nome<br><input type="text" class="estilo_label" name="nome"/></label>
			<label>Sobrenome<br><input type="text" class="estilo_label" name="sobrenome"/></label>
			<label>Pais<br><input type="text" class="estilo_label" name="pais"/></label>
			<label>Região<br><input type="text" class="estilo_label" name="regiao"/></label>
			<label>E-mail<br><input type="text" class="estilo_label" name="email"/></label>
			<label>Senha<br><input type="password" class="estilo_label" name="senha"/></label>
			<label>Confirme sua senha<br><input type="password" class="estilo_label" name="confirmacao_senha"/></label>
			<input type="submit" class="sb bradius" value="Cadastrar" name="submit"/>


		
		</form>
	</div>
	
</body>





</html>