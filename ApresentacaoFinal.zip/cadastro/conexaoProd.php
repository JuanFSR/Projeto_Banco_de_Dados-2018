<?php

$conexao=mysqli_connect('localhost','root','','criar_produto');
    mysqli_set_charset($conexao, 'utf-8');
    if($conexao->connect_error){
        die("Falha ao realizar conexão: " .$conexao->connect_error);
    }
    
    $id_prod=md5(uniqid(""));
    
    $nome=$_POST['nome'];
	$descricao =$_POST['descricao'];
	$preco=$_POST['preco'];
	$vendedor=$_POST['vendedor'];
	$categoria=$_POST['categoria'];
	$nome_imagem=$_POST['nome_imagem'];

    
    $sqlpercorre=mysqli_query($conexao, "SELECT * FROM produtos WHERE id_prod='$id_prod'");
    $num=mysqli_num_rows($sqlpercorre);
    if($num==0){
        $sql="INSERT INTO usuarios (nome, decricao, preco, vendedor, categoria, , nome_imagem) VALUES";
        $sql="('$nome', '$descricao', '$preco', '$vendedor', '$categoria','$nome_imagem')";
        if($conexao->query($sql)===true){
            echo "produto cadastrado com sucesso!";
            
        }
        else{
            echo "Erro: ". $sql . "<br>" . $conexao->error;
        }
        $conexao->close();
    }
    else{
        echo "Já existe essa id cadastrada!";
    }
?>