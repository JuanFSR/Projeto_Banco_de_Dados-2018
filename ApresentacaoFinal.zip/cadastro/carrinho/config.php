<?php
	$servidor = "localhost";
	$usuario = "root";
	$senha="";
	$dbname = "criar_produto";

	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname) or die(mysqli_error());


?>