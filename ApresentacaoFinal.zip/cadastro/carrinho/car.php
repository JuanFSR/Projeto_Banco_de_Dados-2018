<?php
	session_start();

	if(!isset($_SESSION['itens'])){
		$_SESSION['itens'] = array();
	}

	//adiciona o produto

	if(isset($_GET['add'] && $_GET['add']=='add')){
		$id = intval($_GET['id']);
			if(!isset($_SESSION['itens'] [$id])){
				$_SESSION['itens'] [$id] = 1;
			}
			else{
				$_SESSION['itens'] [$id] +=1;
			}


	}
if(count($_SESSION['itens'])==0){
	echo'Carrinho vazio<br><a href="index.php">Adicionar produtos</a>';
}
else{
	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname) or die(mysqli_error());
	foreach ($_SESSION['itens'] as $idProdutos => $quantidade) {
		$select = $conn -> prepare("SELECT * FROM produtos WHERE id=?");
		$select->bindParam(1, $idProd);
		$select ->execute();
		$produtos = $select ->fecthAll();
		$total = $quantidade * $produtos[0]["preco"];
		echo
			$produtos [0]["nome"].'<br/>
			$preco [0]["preco"].'<br/>
			$quantidade [0]["quantidade"].'<br/>';
			$total 
			<a href="remove.php?remover=carrinho& id='.$idProdutos.'">Remover</a>

	}
}

?>

<html>
<head>
	<title>Carrinho de Compras</title>
</head>
<body>
	<table>
		<caption>Carrinho de Compras</caption>
		<thead>
			<tr>
				<th width="244">Produto</th>
				<th width="79">Quantidade</th>
				<th width="89">Pre&ccedil;o</th>
				<th width="100">Subtotal</th>
				<th width="64">Remover</th>
			</tr>
		</thead>
			<form action="?acao-up" method="post">
		<tfoot>
			<tr>
				<td colspan="5"><input type="submit" name="atcar" value="Atualizar Carrinho/"></td>
					<tr>
				<td colspan="5"><a href="painel.php">Continuar comprando</a></td>
		</tfoot>
		
		<tbody>
			<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
		</tbody>		
			</form>
		</table>	

</body>
</html>