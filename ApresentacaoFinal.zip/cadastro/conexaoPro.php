<?php
$host = "localhost";
$usuario = "root";
$senha = "";
$bdname= "criar_produto";

$conn = mysqli_connect($host, $usuario, $senha, $bdname);
	if(!$conn){
		die("Falha na conexão: " . mysqli_connect_error());
	}
	else{
		echo"Conexão realizada";
	}
	


?>