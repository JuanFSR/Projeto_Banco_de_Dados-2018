<?php

$conexao=mysqli_connect('localhost','root','','cadastro');
    mysqli_set_charset($conexao, 'utf-8');
    if($conexao->connect_error){
        die("Falha ao realizar conexão: " .$conexao->connect_error);
    }
    
    $id=md5(uniqid(""));
    
    $nome=$_POST['nome'];
	$sobrenome =$_POST['sobrenome'];
	$pais=$_POST['pais'];
	$regiao=$_POST['regiao'];
	$email=$_POST['email'];
	$senha=$_POST['senha'];
	$confirma_senha=$_POST['confirmacao_senha'];
    
    $sqlpercorre=mysqli_query($conexao, "SELECT * FROM usuarios WHERE email='$email'");
    $num=mysqli_num_rows($sqlpercorre);
    if($num==0){
        $sql="INSERT INTO usuarios (nome, sobrenome, pais, regiao, email, senha, confirma_senha) VALUES";
        $sql="('$nome', '$sobrenome', '$pais', '$regiao', '$email', '$senha', '$confirma _senha')";
        if($conexao->query($sql)===true){
            echo "Usuário cadastrado com sucesso!";
            
        }
        else{
            echo "Erro: ". $sql . "<br>" . $conexao->error;
        }
        $conexao->close();
    }
    else{
        echo "Email já cadastrado!";
    }
?>