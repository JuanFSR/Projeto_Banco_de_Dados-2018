<?php
	
$host = "localhost";
$user = "root";
$pass = "";
$database = "criar_produto";
$connection = mysqli_connect($host, $user, $pass, $database);
 
	$result_produto = "SELECT * FROM produtos WHERE categoria LIKE '%sport%e%' LIMIT 45";
	$resultado_produto = mysqli_query($connection, $result_produto);
	if($resultado_produto === FALSE) {
    // Consulta falhou, parar aqui 
    die(mysqli_error($connection));
	}	

?>

<html>

<head>
	<title>Resultado das pesquisas</title>
	<link rel="stylesheet" type="text/css" href="result.css">
	    <meta name="viewport" content="widh= device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="painel.css">
       <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>

<body>


    <nav class="menu">
        <ul>
        <li><a href="painel.php">Home</a></li>
        <li><a href="#">Categoria</a>
            <ul>
                <li><a href="catRoupas.php">Roupas</a></li>
                <li><a href="catElet.php">Eletrônicos</a></li>
                <li><a href="catComp.php">Computadores</a></li>
                <li><a href="#">Esportes</a></li>
                <li><a href="catCasa.php">Casa</a></li>
            </ul>
        </li>
        <li><a href="#">Produto</a>
            <ul>
                <li><a href="#">Adicionar Prod.</a></li>
            </ul>
        </li>
        <li><a href="#">Carrinho</a>
            <ul>
            <li><a href="#">Ver carrinho</a></li>
            </ul>
        </li>
        <li><a href="logout.php">Sair</a></li>
        <li><a href="#"> Nome</a></li>

        <ul>
    </nav>
    <br>
<div id="barr" class="barras">
        
        <div id="divBusca">
        <form name="buscar" method="post" action="results.php">
            <input type="text" class="txtBusca" name="pesquisar" id="txtBusca" placeholder="Buscar..."/>
            <input type="submit" class="btnBusca" name="btnBusca" value="Buscar">
        </form>
        </div>
        <br><br>

<br/>
<br/>
<br/>
<br/>
<hr>
<div id="row" class="row">
<?php while($rows_cursos= mysqli_fetch_array($resultado_produto)){ ?>
		//echo "Nome do Produto:".$rows_cursos['nome']."<br/>";
		<div id="colun" class="col-xs-6 col-md-3">
    <div id="thumbnail" class="thumbnail">
      <img class="TamanhoImg" <?php echo "src='foto/".$rows_cursos['nome_imagem']."'";?>  alt="">
      <div class="caption text-center">
        <h3><?php echo $rows_cursos['nome']; ?></h3>
        <p>R$<?php echo $rows_cursos['preco']; ?></p>
        <p><a href="car.php?add=$id" class="btn btn-primary" role="button">Comprar</a></p>
      </div>
        </div>
    </div>
	<?php } ?>
	</div>
        </div>



<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script scr="js/bootstrap.min.js"></script>
</body>

</html>