-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: 04-Dez-2018 às 20:52
-- Versão do servidor: 5.7.23
-- versão do PHP: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cadastro`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `nome` text NOT NULL,
  `sobrenome` text NOT NULL,
  `pais` text NOT NULL,
  `regiao` text NOT NULL,
  `email` text NOT NULL,
  `senha` text NOT NULL,
  `confirma_senha` text NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`nome`, `sobrenome`, `pais`, `regiao`, `email`, `senha`, `confirma_senha`, `id`) VALUES
('Juan\r\n', 'Rangel', 'Brasil', 'Sul', 'juanfrangel15@gmail.com', '123', '123', 2),
('jjjj', 'Rangel', 'Eua', 'Norte', 'jjj@gmail.com', 'juan', 'juan', 4),
('Nicollas', 'KC', 'EstÃ´nia', 'PenÃ­nsula PeninsÃ³lica', 'nkcviadoquemle@yahoo.com', '9999999999', ' _senha', 8),
('Fulano', 'Silva', 'Brasil', 'Norte', 'fulano@gmail.com', '555', ' _senha', 9),
('Fulano', 'Silva', 'Brasil', 'Norte', 'fulan@gmail.com', '555', ' _senha', 10),
('Fulano', 'Silva', 'Brasil', 'Norte', 'ful@gmail.com', '888', ' _senha', 11);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
