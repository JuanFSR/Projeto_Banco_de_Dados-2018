<?php
$host = "localhost";
$user = "root";
$pass = "";
$database = "criar_produto";
$connection = mysqli_connect($host, $user, $pass) or die (mysqli_error());
	mysqli_select_db($database) or die (mysqli_error());

?>