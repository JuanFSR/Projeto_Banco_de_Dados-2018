<?php
$host = "localhost";
$user = "root";
$pass = "";
$banco = "cadastro";
$conexao = mysqli_connect($host , $user, $pass, $banco) or die(mysqli_error());
mysqli_select_db($conexao , $banco) or die(mysqli_error());

?>
<?php
	session_start();
	if(!isset($_SESSION["email"]) || !isset($_SESSION["senha"])){
		header("Location: login.php");
		exit;
	}
?>



<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Teste</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="painel.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="testec.css">
</head>
<
	<header>
	<div id="barr" class="barras">
	<ul>
		<li>Início</li>
		<li>Produtos</li>
		<li>Categoria</li>
		<li>Preço</li>
		<li><a href="logout.php">Sair</a></li>
		</ul>	
	
	</div>
	<div id="divBusca">
  		<form name="buscar" method="post" action="results.php">
  			<input type="text" id="txtBusca" placeholder="Buscar..."/>
  			<input type="submit" name="btnBusca" value="Buscar">
		</form>
		</div>
	</header>
	<div class="conteiner-fluid">
	<div class="row">
	<div class="col-xs-12 col-sm-2 col-md-2 col-lg-2 coluna1">
	<div id="lateral" class="coluna">
		<ul>
		<li>Perfil</li>
		<li>E-mail para contato</li>
		<li>Coloque um produto à venda</li>
		</ul>
	</div>
		</div>
	
	<div class="col-xs-12 col-sm-10 col-md-10 col-lg-10 coluna2">
	
	<img class="imagem" src="imagem.png" alt="minha imagem">
	</div>
			</div>
		</div>
</body>
</html>
