<?php
	include "conecta.php";
?>
<html>

<head>
	<title>Resultado das pesquisas</title>
</head>

<body>

	<?php
	$buscar = $_POST['buscar'];
	$sql = mysqli_query("SELECT * FROM criar_produto WHERE nome_prod LIKE '%".$buscar."%'");
	$row = mysqli_num_rows($sql);
		if($row > 0){
			while($linha = mysqli_fetch_array($sql)){
				$nome_prod = $linha['nome_prod'];
				$valor = $linha['valor'];
				$cod_prod = $linha['cod_prod'];
				echo"<strong>Nome do Produto:</strong>".@$nome_prod;	
				echo"<br/><br/>";
				echo"<strong>Valor:</strong>".@$valor;	
				echo"<br/><br/>";
				echo"<strong>Código do produto:</strong>".@$cod_prod;	
				echo"<br/><br/>";

			}
		}
		else{
			echo"Desculpe nenhum produto foi encontrado!";
		}


	?>


</body>

</html>